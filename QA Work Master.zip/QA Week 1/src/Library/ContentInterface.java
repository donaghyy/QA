package Library;

public interface ContentInterface {
	
	public void searchContent();
	public void removeItem();
	public void removeItemID(int ID);
	public void updateItem();

}
