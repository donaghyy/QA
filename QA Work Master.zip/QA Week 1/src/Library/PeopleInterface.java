package Library;

public interface PeopleInterface {
	
	public void searchPeople();
	public void addPerson();
	public void removePerson(String ID);

}
