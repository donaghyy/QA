public class HelloWorld {

    public static void main(String[] args) {
        
        String s = "Hello World!";
    		//System.out.println(hw);
    	
    	hw(s);
    
    }
    
    public static String hw (String hw) {
		
    	System.out.println(hw);
    	return hw;
    	
    }
    
}