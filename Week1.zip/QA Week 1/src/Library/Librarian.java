package Library;

import java.util.ArrayList;
import java.util.Scanner;

public class Librarian extends People {

	public Librarian(String ID, String name, String password) {
		super(ID, name, password);
	}
	
	Library l = new Library();
	ArrayList<People> pa = l.getPA();
	
	public void issueContent(int ID) {
		int i = 0;
		
		/*for(People p : pa) {
			if((User)pa.get(i).setItemsIssued());
		}*/
	}
	
	public void returnContent() {
		return;
	}
	
	

	
	
	
	
	
}
