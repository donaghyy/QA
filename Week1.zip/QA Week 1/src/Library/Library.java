package Library;

import java.util.ArrayList;
import java.util.Scanner;

public class Library {

	 ArrayList<Content> itemArray = new ArrayList<Content>();
	 ArrayList<People> peopleArray = new ArrayList<People>();
	 
	 public ArrayList<People> getPA() {
		 return peopleArray;
	 }
	
	public static void main(String[] args) {
		Library l = new Library();
		
		// Content
		Book b1 = new Book (1, "Book", "James Dickerson", "The Mediocore Summer", 12, 4, true, true, 1000);
		Book b2 = new Book (2, "Book", "Sarah Howell", "Die Python Die", 16, 2, false, false, 847);
		
		Magazine m1 = new Magazine (3, "Magazine", "Hello", "Are You Smarter Than OJ?", 2, 2, true);
		Magazine m2 = new Magazine (4, "Magazine", "OK", "Top 10 Summer Tips", 2, 1, false);
		
		Journal j1 = new Journal (5, "Journal", "Bugzy Malone", "Journal of an Evil Genius", 22, 4, true, "Music");
		Journal j2 = new Journal (6, "Journal", "Adam Shahzad", "The Complaining Machine", 23, 1, false, "Life");
		
		// People
		User u1 = new User("u01", "John", "password", 19, "john@outlook.com", 1);
		User u2 = new User("u02", "Peter", "password", 36, "peter@outlook.com", 0);
		User u3 = new User("u03", "Sarah", "password", 22, "sarah@outlook.com", 3);
		Librarian l1 = new Librarian("l01", "Mary", "password");
		
		l.itemArray.add(b1);
		l.itemArray.add(b2);
		l.itemArray.add(m1);
		l.itemArray.add(m2);
		l.itemArray.add(j1);
		l.itemArray.add(j2);
		l.peopleArray.add(u1);
		l.peopleArray.add(u2);
		l.peopleArray.add(u3);
		l.peopleArray.add(l1);
		
		
		//removeItem();
		//l.updateItem();
		//l.searchContent();		// used to quickly find item
		l.searchPeople();		// used to find person by name - then update, remove or view outstanding items.
		
	}
	
	public  void searchContent() {		// Searches an individual item by ID

		System.out.println("Please enter the ID of the item");
		Scanner sc = new Scanner(System.in);

		String temp = sc.nextLine();
		int search = Integer.parseInt(temp);

		

		for (int i = 0; i < itemArray.size() - 1; i++) {

			if (itemArray.get(i).getID() == search) {

				System.out.println(itemArray.get(i).toString());
				System.out.println("________________________");

				//Library.printArray(); // asks if they'd like to print array

			}

		}
	}
	
	public void searchPeople() {

		System.out.println("Please enter Name");
		Scanner sc = new Scanner(System.in);

		String search = sc.nextLine();

		for (int i = 0; i < peopleArray.size(); i++) {

			if (peopleArray.get(i).getName().equals(search)) {

				System.out.println(peopleArray.get(i).toString()); // modify toString
				System.out.println("________________________");

				
				if (peopleArray.get(i).getName().equals("Mary")) {
					System.out.println("Please indicate: (1)(2)");
					System.out.println("(1) Update Record" + "\n(2) Delete Record");
				}
				else if(peopleArray.get(i).getName().equals(search)) {
					System.out.println("Please indicate: (1)(2)(3)");
					System.out.println("(1) Update Record" + "\n(2) Delete Record" + "\n(3) Outstanding");
				}
				
				
				String temp = sc.nextLine();
				int input = Integer.parseInt(temp);
				
				if (input == 1) {
					String ID = peopleArray.get(i).getpID();
					updatePerson(ID);
				}
				else if (input == 2) {
					String ID = peopleArray.get(i).getpID();
					removePerson(ID);
				}
				else if (input == 3) {
					String ID = peopleArray.get(i).getpID();
					outstandingContent(ID);
				}
			}
		}	
	}
	
	public void updatePerson(String ID) {
		for (int j = 0; j<peopleArray.size(); j++) {
			
		if (peopleArray.get(j).getpID() == ID) {

			System.out.println("Please indicate what you want to Update: (1)(2)(3)");
			System.out.println("(1) ID" + "\n(2) Name" + "\n(3) Password");
			
			Scanner sc = new Scanner(System.in);
			String temp = sc.nextLine();
			int input = Integer.parseInt(temp);
			
			if (input == 1) {
				String userInput = sc.nextLine();
				peopleArray.get(j).setID(userInput);
			}
			else if (input == 2) {
				String userInput = sc.nextLine();
				peopleArray.get(j).setName(userInput);
			}
			else if (input == 3) {
				String userInput = sc.nextLine();
				peopleArray.get(j).setPassword(userInput);
			}
			System.out.println("Updated Record: " + peopleArray.get(j).toString()); 		// updated record
			System.out.println("________________________");
		}
	}
	}
	
	
	public void outstandingContent(String ID) {
		
		for (int i = 0; i < itemArray.size() - 2; i++) {

			if (peopleArray.get(i).getpID() == ID) {

				int issued = ((User)peopleArray.get(i)).getItemsIssued();
				System.out.println("Number of items currently outstanding: " + issued);
				System.out.println("________________________");


			}

		}
	}

	
	public void removePerson(String ID) {
		
		for (int i = 0; i < peopleArray.size()-1; i++) {

			if (peopleArray.get(i).getpID() == ID) {

				peopleArray.remove(i);
				System.out.println("Record Removed, " + peopleArray.size() + " people in the Array");
				System.out.println("________________________");
				
				
				

			}
			
		}
	}
	
	public  void removeItem() {
		System.out.println("Please enter the ID of the item you wish to Remove");
		Scanner sc = new Scanner(System.in);
		int search = sc.nextInt();

		for (int i = 0; i < itemArray.size()-1; i++) {

			if (itemArray.get(i).getID() == search) {

				itemArray.remove(i);
				System.out.println("Item Removed, " + itemArray.size() + " items in the Library");
				System.out.println("________________________");
				
				printItemArray();	// asks if they'd like to print array
				

			}
			
		}
	}
	
	public  void updateItem() {
		
		printItemArray();
		
		System.out.println("\nPlease enter the ID of the item you wish to Update");
		Scanner sc = new Scanner(System.in);
		String search = sc.nextLine();
		int temp2 = Integer.parseInt(search);

		for (int i = 0; i < itemArray.size(); i++) {

			if (itemArray.get(i).getID() == temp2) {

			//	ask for info and store as variables, ask if they want to edit 'name'eg
				System.out.println("Please indicate: (1)(2)(3)(4)(5)(6)(7)");
				System.out.println("(1) ID" + "\n(2) Category" + "\n(3) Author"
						+ "\n(4) Title" + "\n(5) Isle Number" + "\n(6) Rack Number"
						+ "\n(7) Status");
				String temp = sc.nextLine();
				int input = Integer.parseInt(temp);
				
				
				if (input == 1) {
					String input2 = sc.nextLine();
					itemArray.get(i).setID(Integer.parseInt(input2));
				}
				else if (input == 2) {
					String input2 = sc.nextLine();
					itemArray.get(i).setCategory(input2);
				}
				else if (input == 3) {
					String input2 = sc.nextLine();
					itemArray.get(i).setAuthor(input2);
				}
				else if (input == 4) {
					String input2 = sc.nextLine();			// Can only read in 1 word
					itemArray.get(i).setTitle(input2);
				}
				else if (input == 5) {
					String input2 = sc.nextLine();
					itemArray.get(i).setIsleNo(Integer.parseInt(input2));
				}
				else if (input == 6) {
					String input2 = sc.nextLine();
					itemArray.get(i).setRackNo(Integer.parseInt(input2));
				}
				else if (input == 7) {
					String input2 = sc.nextLine();
					itemArray.get(i).setStatus(Boolean.parseBoolean(input2));
				}
				
				System.out.println("Updated Record: " + itemArray.get(i).toString()); 		// updated record
				
				
				
				
				System.out.println("________________________");

			}
			
		}
	}

	public  void printItemArray() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Would you like to display all records? Y/N");
		String temp = sc.next();
		
		if(temp.contains("Y")) {
			for(int j=0; j< itemArray.size()-1; j++) {
				System.out.println(itemArray.get(j).toString());
				System.out.println();
			}
		}
		else if (temp.contains("N")) {
			System.out.println("OK.");
		}
	}
}
