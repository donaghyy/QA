/**
 * 
 */
package LibraryTests;
import Library.*;

import static org.junit.Assert.*;

import org.junit.Test;


public class ContentTest {

	@Test
	public void testPageCount() {
		Book testBook = new Book(1, "Book", "Jimmy Jebus", "This is Title", 
				42, 3, true, true, 420);
		
		assertEquals(testBook.getPageCount(), 420);
	}
	
	@Test
	public void testHardBack() {
		Book testBook = new Book(1, "Book", "Jimmy Jebus", "This is Title", 
				42, 3, true, true, 420);
		
		assertEquals(testBook.isHardBack(), true);
	}
	
	@Test
	public void testUpdateStatus() {
		Book testBook = new Book(1, "Book", "Jimmy Jebus", "This is Title", 
				42, 3, true, true, 420);
		assertTrue(testBook.getStatus());
	}
	
	@Test
	public void testAddItem() {
		
	}
	
	@Test
	public void testRemoveItem() {
		
	}
	
	@Test
	public void testUpdateItem() {
		
	}

}
